#!/bin/bash

mostrar_ayuda() {
    echo "Uso:"
    echo "  /opt/scripts/backup_full.sh ORIGEN DESTINO"
    echo ""
    echo "Ejemplos:"
    echo "  /opt/scripts/backup_full.sh /var/log /backup_dir"
    echo "  /opt/scripts/backup_full.sh /www_dir /backup_dir"
    echo ""
    echo "Descripcion:"
    echo "  Genera un backup comprimido .tar.gz del directorio origen"
    echo "  y lo guarda en el directorio destino."
    echo ""
    echo "Requisitos:"
    echo "  - El origen debe existir."
    echo "  - El destino debe existir."
    echo "  - El destino debe estar montado."
}

if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    mostrar_ayuda
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "ERROR: Debe indicar origen y destino."
    echo "Use -help para ver el modo de uso."
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: El origen no existe o no es un directorio: $ORIGEN"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "ERROR: El destino no existe o no es un directorio: $DESTINO"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "ERROR: El destino no esta montado: $DESTINO"
    exit 1
fi

if [ "$ORIGEN" = "/www_dir" ] || [ "$ORIGEN" = "/backup_dir" ]; then
    if ! mountpoint -q "$ORIGEN"; then
        echo "ERROR: El origen no esta montado: $ORIGEN"
        exit 1
    fi
fi

FECHA=$(date +%Y%m%d)
NOMBRE_ORIGEN=$(basename "$ORIGEN")
ARCHIVO_BACKUP="${NOMBRE_ORIGEN}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup..."
echo "Origen: $ORIGEN"
echo "Destino: $DESTINO/$ARCHIVO_BACKUP"

tar -czf "$DESTINO/$ARCHIVO_BACKUP" "$ORIGEN" 2>/tmp/backup_error.log

if [ "$?" -eq 0 ]; then
    echo "Backup realizado correctamente:"
    echo "$DESTINO/$ARCHIVO_BACKUP"
    exit 0
else
    echo "ERROR: No se pudo realizar el backup."
    cat /tmp/backup_error.log
    exit 1
fi
