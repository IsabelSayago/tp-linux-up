history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
tailscale status
tailscale status
tailscale status
cat /env/os-release
cat /etc/os-release
ip a
cat /etc/network/interfaces
systemctl status ss
systemctl status ssh
ssh-keygen
ssh-copy-id root@100.127.21.62
nano /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
vi /etc/network/interfaces
vi /etc/network/ interfaces
ip a
ip a
ip a
ip a
cat /etc/network/interfaces
exit
cat /root/ .ssh/id_rsa
exit
exit
cat /root/.ssh/id_rsa
exit
exit
Ping -c 8.8.8.8
ping -c 8.8.8.8
ping -c 4 8.8.8.8
exit
cat /etc/ssh/sshd_config
ls -la /root/.ssh/
cat /root/.ssh/id_rsa
exit
cat /root/.ssh/id_rsa > /tmp/id_rsa.txt
cat /root/.ssh/id_rsa > /tmp/id_rsa.txt
cat /root/.ssh/id_rsa > /tmp/id_rsa.txt
exit
exit
exit
lsblk
n
fdisk /dev/sdb
lsblk
lsblk
fdisk /dev/sbd
p
fdisk /dev/sdb
lsbk
lsblk
mkfs.ext4 /dev/sdb2
mkfs.ext4 /dev/sdb2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sbd1/www_dir
mount /dev/sbd1 /www_dir
mount /dev/sbd1 /backoup_dir
df -h
df -h
lsblk
mkdir -p /backup_dir
mount /dev/sdb2 /backup_dir
df -h
nano /etc/fstab
VI /etc/fstab
vi /etc/fstab
amount -a
mount -a
apt update
apt install apache2 php -y
systemctml status apache2
systemctl status apache2
vi /etc/apache2/sited-available/000-default.conf
vi /etc/apache2/sites-available/000-default.conf
systemctl restart apache2
systemctl status apache2
mkdir -p /www_dir
ls /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz
ls /root
ls /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/index.php /www_dir
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir
ls /www_dir
curl 127.0.0.1
vi /etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
systemctl restart apache2
curl 127.0.0.1
ls -l /www_dir
car /www_dir/index.php||||
car /www_dir/index.php
cat /www_dir/index.php
apachectl configtest
ss -tulpn | grep :80
tailscale ip -4
curl https://100.127.21.62/index.php
curl http://100.127.21.62/index.php
tail -n 30 /var/log/apache2/error.log
apt install php-mysqli php-mysql -y
systemctl restart apache2
curl http://100.127.21.62/index.php
tail -n 30 /var/log/apache2/error.log
apt install mariadb-server -y
systemctl start mariadb
systemctl enabbled mariadb
systemctl enabled mariadb
systemctl enable mariadb
systemctl restart apache2
curl http://100.127.21.62/index.php
head -n 20 /www_dir/index.php
mysql
mysql -u lcars -p ingenieria
mysql -u lcars -p ingenieria 
mysql -u lcars -p ingenieria 
MYSQL
mysql
mysql -u lcars -p ingenieria 
systemctl reboot
cat /etc/fstab
cat /root/.ssh/authorized_keys
systemctl ssh status
systemctl status ssh
lsblk
df -h
tailscale status
tailscale up
systemctl restart tailscaled
cat /etc/fstab
vi /etc/fstab
vi /etc/fstab
reboot
cat /etc/fstab
lsblk
mount /dev/sbd1 /home
mount /dev/sdb1 /home
mount /dev/sdb1 /home
vi /etc/fstab
reboot
taiscale status
tailscale status
vi /etc/fstab
blkid /dev/sdb1
lsblk
hostname
cat /etc/os-release
systemctl status ssh
cat /etc/network/interfaces
tar -czvf /tmp/etc.tar.gz /etc
tar -czvf /tmp/root.tar.gz /root
shutdown now
ls /
lsblk
blkid
cat /etc/fstab
nano /etc/fstab
vi /etc/fstab
mount -a
vi /etc/fstab
